from random import randint
import time
def main():
    lowerLimit = int(input("Enter the lower limit"))
    upperLimit = int(input("Enter the Upper limit"))
    lists = []
    count = 0
    n = int(input("Please tell number of random numbers"))
    now = time.time()
    for i in range(0, n):
        random_number = randint(lowerLimit, upperLimit)
        lists.append(random_number)
        count = count + 1
    print(count)
    print(lists)
    sorted_lists = quickSort(lists, 0, len(lists) - 1)
    print(sorted_lists)
    file = open("Sorted_Lists30.txt", "w+")
    for i in sorted_lists:
        file.write(str(i) + " ")
    end = time.time()
    time_difference = end - now
    file.write(str(time_difference) + " ")
    file.close
    print("Time Taken for the algorithm to run is ", time_difference, " Seconds")


# This function takes last element as pivot, places
# the pivot element at its correct position in sorted
# array, and places all smaller (smaller than pivot)
# to left of pivot and all greater elements to right
# of pivot
def partition(arr, low, high):
    i = (low - 1)  # index of smaller element
    pivot = arr[high]  # pivot

    for j in range(low, high):

        # If current element is smaller than or
        # equal to pivot
        if arr[j] <= pivot:
            # increment index of smaller element
            i = i + 1
            arr[i], arr[j] = arr[j], arr[i]

    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return (i + 1)


# The main function that implements QuickSort
# arr[] --> Array to be sorted,
# low  --> Starting index,
# high  --> Ending index

# Function to do Quick sort
def quickSort(arr, low, high):
    if low < high:
        # pi is partitioning index, arr[p] is now
        # at right place
        pi = partition(arr, low, high)

        # Separately sort elements before
        # partition and after partition
        quickSort(arr, low, pi - 1)
        quickSort(arr, pi + 1, high)
    return arr


main()
# Driver code to test above


