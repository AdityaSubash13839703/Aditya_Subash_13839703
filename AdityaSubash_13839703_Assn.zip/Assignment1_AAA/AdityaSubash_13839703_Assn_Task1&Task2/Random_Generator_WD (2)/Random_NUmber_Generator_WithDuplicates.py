from random import randint
import time
def random_number_generator():
    lowerLimit = int(input("Enter the lower limit"))
    upperLimit = int(input("Enter the Upper limit"))
    lists=[]
    count = 0
    file = open("NumberGenerator17.txt","w+" )
    n= int(input("Please tell number of random numbers"))
    now = time.time()
    for i in range(0,n):
        random_number = randint(lowerLimit,upperLimit)
        lists.append(random_number)
        file.write(str(random_number) + " ")
        count = count+1
    print(count)
    print(lists)
    end = time.time()
    time_difference  = end - now
    print("Time Taken for the algorithm to run is " ,time_difference, " Seconds" )
    file.write(str(time_difference) + " ")
    file.close()

random_number_generator()



