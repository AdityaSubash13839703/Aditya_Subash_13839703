from random import randint
import time
def random_number_generator():
   
    lowerLimit = int(input("Enter the lower limit"))
    upperLimit = int(input("Enter the Upper limit"))
    lists = []
    count = 0
    n = int(input("Please tell number of random numbers"))
    now = time.time()
    for i in range(0, n):
        random_number = randint(lowerLimit, upperLimit)
        lists.append(random_number)
        count = count + 1
    print(count)
    print(lists)
    sorted_lists = insertion_sort(lists)
    print(sorted_lists)
    file = open("Sorted_Lists4.txt", "w+")
    for i in sorted_lists:
        file.write(str(i) + " ")
    end = time.time()
    time_difference = end - now
    file.write(str(time_difference) + " ")
    file.close()
    print("Time Taken for the algorithm to run is ", time_difference, " Seconds")


def insertion_sort(array):
    for index in range(1, len(array)):
        currentValue = array[index]
        currentPosition = index
        while currentPosition > 0 and array[currentPosition - 1] > currentValue:
            array[currentPosition] = array[currentPosition - 1]
            currentPosition = currentPosition - 1

        array[currentPosition] = currentValue

    return array


random_number_generator()
