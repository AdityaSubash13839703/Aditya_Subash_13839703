from random import randint
import time
from datetime import datetime


def random_number_generator():
    lists = []
    lowerlimit = int(input("Enter the number"))
    Upperlimit = int(input("Enter the number"))
    file = open("NumberGenerator21.txt", "w+")

    n = int(input("Number of loops"))
    now = datetime.now()
    i = 0

    while i < n:
        random_number = randint(lowerlimit, Upperlimit)
        duplicates = duplicate_finder(lists, random_number)
        if duplicates == False:
            lists.append(random_number)
            file.write(str(random_number) + "  ")
        else:
            continue
        i = i + 1
    print(lists)
    print(len(lists))
    end = datetime.now()
    time_difference = end - now
    print("Time Taken for the algorithm to run is ", time_difference, " Seconds")
    file.write(str(time_difference) + "  ")
    file.close()


def duplicate_finder(arr, num):
    for i in range(0, len(arr)):
        if arr[i] == num:
            return True
    return False


random_number_generator()




